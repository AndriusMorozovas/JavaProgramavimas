import java.util.Scanner;

public class Uzd01 {

	public static void main(String[] args) {
		Scanner reader = new Scanner(System.in);
		System.out.println("Kiek pamokų yra pirmadienį? ");
		int a = reader.nextInt();
		System.out.println("Kiek pamokų yra antradienį? ");
		int b = reader.nextInt();
		System.out.println("Kiek pamokų yra trečiadienį? ");
		int c = reader.nextInt();
		System.out.println("Kiek pamokų yra ketvirtadienį? ");
		int d = reader.nextInt();
		System.out.println("Kiek pamokų yra penktadienį? ");
		int e = reader.nextInt();
		reader.close();

		int sk = (a + b + c + d + e);
		int min = 45;

		System.out.println("Pamokų skaičius: " + sk);
		System.out.println("Tai sudaro minučių: " + (sk * min));

	}

}
