
public class Uzd03 {

	public static void main(String[] args) {
		int a = -199;
		for (int i = -98; i > a; i--) {
			i = i - 2;
			System.out.println(i);
		}
		int b = -100;
		while (b > -200) {
			System.out.println(b + "");
			b = b - 3;
		}
	}

}
