import java.util.Scanner;

public class Uzd04 {

	}


