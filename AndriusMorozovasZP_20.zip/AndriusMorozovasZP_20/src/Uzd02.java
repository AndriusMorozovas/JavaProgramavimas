import java.util.Scanner;

public class Uzd02 {

	public static void main(String[] args) {
		Scanner reader = new Scanner(System.in);
		System.out.println("Įveskite dėžių skaičių: ");
		int d = reader.nextInt();
		System.out.println("Įveskite knygų skaičių: ");
		int k = reader.nextInt();
		System.out.println("Įveskite, kelios knygos telpa į dėžę: ");
		int n = reader.nextInt();
		reader.close();
		
		if ((d * n) >= k) {
			System.out.println("Knygos telpa į dėžes.");
		}
		else if ((d * n) < k) {
			System.out.println("Knygos netelpa į dėžes.");
			System.out.println("Į dėžes netilpo " + (k % (d * n)) + " knygos/-ą/-ų");
		}
	}

}
