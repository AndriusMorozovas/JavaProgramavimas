import java.util.Scanner;

public class Uzd05 {

		public static void main(String[] args) {
			Scanner reader = new Scanner(System.in);
			System.out.println("Pirmas įvertinimas: ");
			int a = reader.nextInt();
			System.out.println("Antras įvertinimas: ");
			int b = reader.nextInt();
			System.out.println("Trečias įvertinimas: ");
			int c = reader.nextInt();
			gautiGeriausiaIvertinima(a, b, c);
			reader.close();
		}

		private static void gautiGeriausiaIvertinima(int a, int b, int c) {
			return mathMax;
			

	}

}
